package rts.unit

import rts.core.BattleLogger
import rts.core.MoveStrategy
import rts.core.Position

/**
 * GameUnit
 * - 모든 유닛의 기본 형태 (이름, 위치, 이동능력, 비행 여부, logger)
 *
 * 책임:
 *  - 이동(move)
 *  - 상태 표현(toString)
 *
 * 공격/수송 같은 특수 능력은 여기서 다루지 않는다.
 * → SRP(단일 책임): GameUnit은 "기본 유닛" 역할만 가진다.
 */
abstract class GameUnit(
    val name: String,
    var position: Position,
    private val moveStrategy: MoveStrategy,
    val isFlying: Boolean,
    protected val logger: BattleLogger
) {
    /**
     * move()
     * - 실제 이동 방식은 moveStrategy가 담당
     * - GameUnit은 "난 이동할 수 있음"만 알고 "어떻게 이동하는지"는 모른다.
     *   → DIP (추상 의존)
     *   → OCP (새 이동 방식 추가 시 GameUnit 수정 불필요)
     */
    open fun move(to: Position) {
        moveStrategy.move(this, to, logger)
        position = to
    }

    override fun toString(): String {
        return buildString {
            append("$name @ $position")
            if (isFlying) append(" [FLYING]")
        }
    }
}