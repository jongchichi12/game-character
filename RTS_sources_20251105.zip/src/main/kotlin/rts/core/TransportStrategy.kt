package rts.core

import rts.unit.GameUnit
import rts.unit.TransportUnit

/**
 * TransportStrategy
 * - 수송 유닛이 병력을 태우고 내리는 규칙을 정의
 * - TransportUnit은 이 전략을 이용해서만 탑승/하차를 수행한다.
 *
 * OCP:
 *  새로운 수송 방식(지상 수송 차량, 순간이동 포탈 등)을
 *  새로운 전략 클래스로 추가할 수 있다.
 */
interface TransportStrategy {
    fun board(transporter: TransportUnit, passenger: GameUnit, logger: BattleLogger)
    fun unloadAll(transporter: TransportUnit, logger: BattleLogger)
}

/**
 * ShuttleTransport
 * - 하늘을 날아 이동하는 셔틀(수송선)의 기본 탑승/하차 규칙
 * - capacity: 한 번에 태울 수 있는 최대 인원
 */
class ShuttleTransport(
    private val capacity: Int = 8
) : TransportStrategy {

    override fun board(transporter: TransportUnit, passenger: GameUnit, logger: BattleLogger) {
        if (transporter.passengers.size >= capacity) {
            logger.log("${transporter.name}: 더 이상 태울 수 없습니다. (정원 $capacity 명)")
            return
        }
        transporter.passengers.add(passenger)
        logger.log("${transporter.name}: ${passenger.name} 탑승 완료. (현재 ${transporter.passengers.size}명)")
    }

    override fun unloadAll(transporter: TransportUnit, logger: BattleLogger) {
        if (transporter.passengers.isEmpty()) {
            logger.log("${transporter.name}: 내릴 유닛이 없습니다.")
            return
        }

        logger.log("${transporter.name}: 착륙 지점에서 탑승 병력을 전원 하차시킵니다.")
        val dropPosition = transporter.position

        transporter.passengers.forEach { unit ->
            unit.position = dropPosition
            logger.log(" - ${unit.name} 가 ${dropPosition} 위치에 하차했습니다.")
        }

        transporter.passengers.clear()
    }
}