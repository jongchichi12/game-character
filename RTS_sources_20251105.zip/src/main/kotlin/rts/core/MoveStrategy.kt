package rts.core

import rts.unit.GameUnit

/**
 * MoveStrategy
 * - "어떻게 이동하는가?"만 책임지는 전략 인터페이스
 * - GameUnit은 moveStrategy를 주입받아서 사용한다.
 * - OCP:
 *   새로운 이동 방식(순간이동, 점프 등)을 추가하더라도
 *   GameUnit 코드는 바꿀 필요가 없다.
 */
interface MoveStrategy {
    fun move(who: GameUnit, to: Position, logger: BattleLogger)
}

/** 걸어서 이동 (궁수 등 지상 보병) */
class WalkMove : MoveStrategy {
    override fun move(who: GameUnit, to: Position, logger: BattleLogger) {
        logger.log("${who.name} 은/는 걸어서 $to 로 이동합니다.")
    }
}

/** 말을 타고 이동 (기사 등 기동력 있는 지상 유닛) */
class HorseMove : MoveStrategy {
    override fun move(who: GameUnit, to: Position, logger: BattleLogger) {
        logger.log("${who.name} 은/는 말을 타고 $to 로 빠르게 이동합니다.")
    }
}

/** 비행 이동 (그리폰, 셔틀 등 공중 유닛) */
class FlyMove : MoveStrategy {
    override fun move(who: GameUnit, to: Position, logger: BattleLogger) {
        logger.log("${who.name} 은/는 하늘을 날아 $to 로 이동합니다.")
    }
}